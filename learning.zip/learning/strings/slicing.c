#include <stdio.h>
#include <string.h>
void slicer(char str[], int start , int stop , char newStr[]);
int main()
{

    int start;
    int stop;

    char str[] = "HolyWater.";

    printf("Enter starting point index: ");
    scanf("%d",&start);
    printf("Enter stoping point index: ");
    scanf("%d",&stop);

    char newStr[10];
    slicer(str,start,stop,newStr);

    puts(newStr);
    
    
    return 0;
}

void slicer(char str[], int start , int stop , char newStr[])
{
    int looper = 0;
    while (start <= stop)
    {
        // printf("%c",str[start]);
        newStr[looper] = str[start];
        start = start+1;
        looper = looper+1;

    }
    // printf("\n");

}