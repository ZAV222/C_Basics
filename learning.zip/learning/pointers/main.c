#include <stdio.h>


// void square(int n);
// void _square(int *n);

// void swap(int x, int y);

// void _swap(int *x, int *y);

void doWork(int x, int y, int *sum, int *prod, int *avg);
int main()
{
    // int x = 2;
    // int *ptr = &x;
    // int _x = *ptr;
    // printf("%d\n",_x);
    // printf("%p\n", &x);
    // printf("%p\n", ptr);

    // printf("%u\n",ptr); // but it throws warning printing pointer as a unsigned int.



    // int *ptr;
    // int x;

    // ptr = &x;
    // *ptr = 0;

    // printf("Value of x: %d\n",x);
    // printf("Value of *ptr: %d\n",*ptr);

    // *ptr = *ptr+5;
    // printf("Value of x: %d\n",x);
    // printf("Value of *ptr: %d\n",*ptr);

    // *ptr = *ptr+1;
    // printf("Value of x: %d\n",x);
    // printf("Value of *ptr: %d\n",*ptr);


    // float price = 16.00;

    // float *ptr = &price;

    // float **pptr = &ptr;

    // int i=5;
    // int *ptr = &i;
    // int **pptr = &ptr;

    // printf("%d\n",**pptr);

    // int number = 4;
    // square(number);
    // printf("Number: %d\n",number);

    // _square(&number);
    // printf("Number: %d\n",number);

   
    // _swap(&x,&y);
    // printf("swap: x = %d , y = %d\n",x,y);


    int x = 3;
    int y = 3;
    int sum,prod,avg;

    doWork(x,y,&sum,&prod,&avg);
    printf("Sum, product and average of %d and %d: \n",x,y);
    printf("Sum = %d, prod = %d, avg = %d\n", sum,prod,avg);

    
    return 0;
}

// void square(int n)
// {
//     n = n*n;
//     printf("Square: %d\n",n);
// }

// void _square(int *n)
// {
//     *n = (*n)*(*n);
//     printf("Square: %d\n",*n);
// }

// void swap(int x, int y) 
// {
//     int t;

//     t = x;

//     x = y;

//     y = t;

//     // printf("After swap: x = %d, y = %d\n",x,y);




// }

// void _swap(int *x, int *y)
// {
//     int t = *y;
//     *y = *x;
//     *x = t;
// }



void doWork(int x, int y, int *sum, int *prod, int *avg)
{
    *sum = x+y;
    *prod = x*y;
    *avg = (x+y)/2;

}