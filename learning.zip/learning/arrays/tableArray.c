#include <stdio.h>

int main()
{
    int table[2][10];

    int looper = 0;
    int tabler = 0;
    while (looper<10)
    {
    
        table[0][looper] = (tabler+1) * 2;
        looper = looper+1;
        tabler = tabler+1;
    }

    tabler = 0;
    looper = 0;

    while (looper<10)
    {
    
        table[1][looper] = (tabler+1) * 3;
        looper = looper+1;
        tabler = tabler+1;
    }

    looper = 0;

    while (looper<10)
    {
        printf("%d ",table[0][looper]);
        
        looper = looper+1;
    }
    printf("\n");

    looper = 0;

    while (looper<10)
    {
     
        printf("%d ",table[1][looper]);
        looper = looper+1;
    }
    printf("\n");





    
    return 0;
}