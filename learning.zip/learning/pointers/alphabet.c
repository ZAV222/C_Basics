#include <stdio.h>

int main() {
    char alphabet[] = "abcdefghijklmnopqrstuvwxyz"; // Array with the alphabet
    char *ptr = alphabet; // Pointer to the first element of the array

    while (*ptr != '\0') { // Loop until the null terminator is reached
        printf("%c ", *ptr);
        ptr++; // Move the pointer to the next character
    }
    printf("\n");

    ptr= ptr-1;

    // Print the characters in reverse order
    while (ptr >= alphabet) {
        printf("%c ", *ptr);
        ptr = ptr-1;
    }
    printf("\n");
    return 0;
}