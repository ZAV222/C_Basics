#include <stdio.h>  
  
int main() {  
    int size = sizeof(int);  
    printf("Size of int: %d bytes\n", size);  
  
    return 0;  
}  