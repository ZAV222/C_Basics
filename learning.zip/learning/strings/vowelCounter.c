#include <stdio.h>

int main()
{
    char name[20] = "Parikshit Acharya";

    int looper = 0;
    int Acount = 0;
    int Ecount = 0;
    int Icount = 0;
    int Ocount = 0;
    int Ucount = 0;
    while (looper<18)
    {
        if (name[looper] == 'A' || name[looper] == 'a')
        {
            Acount = Acount+1;
            // printf("%c : %d",name[looper], Acount);
        }

        if (name[looper] == 'E' || name[looper] == 'e')
        {
            Ecount = Ecount+1;
            // printf("%c : %d",name[looper], Ecount);
        }

        if (name[looper] == 'I' || name[looper] == 'i')
        {
            Icount = Icount+1;
            // printf("%c : %d",name[looper], Icount);
        }

        if (name[looper] == 'O' || name[looper] == 'o')
        {
            Ocount = Ocount+1;
            // printf("%c : %d",name[looper], Ocount);
        }

        if (name[looper] == 'U' || name[looper] == 'u')
        {
            Ucount = Ucount+1;
            // printf("%c : %d",name[looper], Ucount);
        }
        looper = looper+1;
    }

    printf("A comes %d times.\n",Acount);
    printf("E comes %d times.\n",Ecount);
    printf("I comes %d times.\n",Icount);
    printf("O comes %d times.\n",Ocount);
    printf("U comes %d times.\n",Ucount);
   
    int TotalVowels = Acount+Ecount+Icount+Ocount+Ucount;
    printf("Total occurance of vowels is %d\n",TotalVowels);
    return 0;
}
