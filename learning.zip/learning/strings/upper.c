#include <stdio.h>
#include <ctype.h>
#include <string.h>

void upper(char str[]);
int main()
{
    char str[] = "hello World";
    upper(str);
    puts(str);
    return 0;
}

void upper(char str[])
{
    int looper = 0;
    int length = strlen(str);
    while (looper<length)
    {
        str[looper] = toupper(str[looper]); 
        looper = looper+1;  
    }
    
}