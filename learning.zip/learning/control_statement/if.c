#include <stdio.h>

int main(){

    int a = 10;

    if (a>9)
    {
        
        printf("%d\n",a);
    }
    
    return 0;
}