#include <stdio.h>
#include <math.h>
int sum(int n);

double sqrt(double n);

int power(int n);
int main()
{

    int summed = sum(3);
    printf("%d\n",summed);

    double sqrtted =  sqrt(4);
    printf("%lf\n",sqrtted);

    int poww = power(4);

    printf("%d\n",poww);

    return 0;

}

int sum(int n)
{
    if (n==0)
    {
        return 0;
    }
    
    int s = sum(n-1);

    int added = s+n;
    return added;
}

int power(int n)
{

    int pw = n*n;
    return pw;

}