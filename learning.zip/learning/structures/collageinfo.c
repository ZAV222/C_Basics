#include <stdio.h>

typedef struct collageInfo
{
   char collageName[10];
   char collageAdress[10];
   int noOfSutdent;
   int noOfWorkers;
}ci;

typedef struct collageStudentInfo
{
   char studentName[10];
   char studentAddress[10];
   int studentRollNo;
}csi;

typedef struct financeDepartment
{
   int fees;
   char feesPaid[3];
}fd;

typedef struct RTE
{
   char collageTime[10];
   char examTime[10];
}rte;

void printer(ci a, csi b, fd c, rte d );
int main()
{
   ci collage1ci = {"subashu","Itahari-5",3000,40};
   csi collage1csi = {"Ankit","Dhankuti-0",22};
   fd collage1fd = {24000,"Yes"};
   rte collage1rte = {"2021-3-2","11:45"};

   printer(collage1ci, collage1csi,collage1fd, collage1rte );
   return 0;
}

void printer(ci a, csi b, fd c, rte d )
{
   printf("\nCollage Information\n");
   printf("Collage Name: %s\n",a.collageName);
   printf("Collage Address: %s\n",a.collageAdress);
   printf("Collage Students No: %d\n",a.noOfSutdent);
   printf("Collage Workers No: %d\n\n",a.noOfWorkers);

   printf("Collage Student Information\n");
   printf("Student Name: %s\n",b.studentName);
   printf("Student Address: %s\n",b.studentAddress);
   printf("Collage Students No: %d\n\n",b.studentRollNo);

   printf("Collage Finance Information\n");
   printf("Student Fees: %d\n",c.fees);
   printf("Student Fees Paid: %s\n\n",c.feesPaid);

   printf("Collage RTE Information\n");
   printf("Collage Exam Date: %s\n",d.collageTime);
   printf("Collage Exam Time: %s\n\n",d.examTime);
   
}