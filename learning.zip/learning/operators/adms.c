#include <stdio.h>

int main(){
    int a = 2; 
    int b = 2;
    int add = a+b;
    int divide = a/b;
    int multiply = a*b;
    int subtract = a-b;
    int equality = a==b;

    printf("Addition: %d\n",add);
    printf("Division: %d\n",divide);
    printf("Multiplication: %d\n",multiply);
    printf("Subtraction: %d\n",subtract);
    printf("equality: %d\n",equality);
    if (equality == 1)
    {
        printf("Equality: True\n");

    }
    
    else
    {
        printf("Equality: False\n");
    }
    
    // binary operatort, bitwise operator, ternary operator, logic and/or/xor/nor operator.
    // assignment operator
    // miscellaneous operator: like sizeof,comma etc.


    return 0;


}