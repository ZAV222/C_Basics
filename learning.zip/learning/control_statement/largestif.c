#include <stdio.h>  
int main()  
{  
    int a, b, c;   
    printf("Enter three numbers?\n");  
    scanf("%d %d %d",&a,&b,&c);  
    if(a>b && a>c)  
    {  
        printf("\n");
        printf("%d is largest",a);  
        printf("\n");
    }  
    if(b>a  && b > c)  
    {  
        printf("\n");
        printf("%d is largest",b);  
        printf("\n");
    }  
    if(c>a && c>b)  
    {  
        printf("\n");
        printf("%d is largest",c);  
        printf("\n");
    }  
    if(a == b && a == c)   
    {  
        printf("\n");
        printf("All are equal");   
        printf("\n");
    }  
  
}  