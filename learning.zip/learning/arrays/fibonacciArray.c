#include <stdio.h>


int main()
{
    int n;
    printf("Enter n (n>2): ");
    scanf("%d",&n);

    int fib[n];

    fib[0] = 0;
    fib[1] = 1;
    
    printf("%d \t",fib[0]);
    printf("%d \t",fib[1]);
    int looper = 2;

    while (looper<n)
    {

        fib[looper] = fib[looper-1] + fib[looper-2];

        printf("%d \t",fib[looper]);

        looper = looper+1;
    }
    printf("\n");
    return 0;
}