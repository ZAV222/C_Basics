#include <stdio.h>
#include <string.h>

// int printLength(char *arr);

int main()
{

    // char str[20];
    // fgets(str,20,stdin);
    // puts(str);

    // char *str = "Hello";
    // puts(str);

    // str = "World";
    // puts(str);

    // char *arr = "ooo";
    // int length = printLength(arr);
    // printf("Length: %d\n",length);


    // char *arr = "Hello";
    // int length = strlen(arr);
    // printf("Length: %d\n",length);

    // char h[]="Hello";
    // char w[]="World";
    // strcpy(h,w);
    // printf("%s\n",h);

    // strcat(h,w);
    // printf("%s\n",h);

    // char w[]="World";
    // char n[] = "nono";

    
    // printf("%d\n",strcmp(w,n));

    

    return 0;
}

// int printLength(char *arr)
// {
//     int looper = 0;
//     while (arr[looper] != '\0')
//     {
//         looper = looper+1;
        
//     }
    
//     return looper;
// }