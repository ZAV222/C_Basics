#include <stdio.h>
#include <stdlib.h>

int main()
{
 
    int *ptr;

    ptr = (int*)calloc(5,sizeof(int));

    
    int looper = 0;
    while (looper<5)
    {
        printf("Enter the number of ptr[%d]: ",looper);
        scanf("%d",&ptr[looper]);
        looper = looper+1;
    }
    printf("\n");
    
    ptr = realloc(ptr,8);

    ptr[5] = 6;
    ptr[6] = 7;
    ptr[7] = 8;
    ptr[8] = 9;
  
    while (looper < 8)
    {
        printf("the number for ptr[%d]: %d\n",looper,ptr[looper]);
        
        looper = looper+1;
    }
    
    free(ptr);


    return 0;
}