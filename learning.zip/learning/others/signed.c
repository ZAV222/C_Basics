#include <stdio.h>  
  
int main() {  
    
    signed int balance = -100;  
    printf("Balance: %d\n", balance);  
  
    return 0;  
}  