#include <stdio.h>
#include <string.h>

void salting(char password[]);
int main()
{

    char pass[20];
    

    scanf("%s",pass);
    // printf("%s\n",pass);

    // strcat(pass,salt);
    // printf("%s\n",pass);

    salting(pass);



    return 0;
}

void salting(char password[])
{
    char salt[] = "123";
    char newPassword[20];
    strcpy(newPassword,password); // Copies store password in newpassowrd variable.
    strcat(newPassword,salt);
    puts(newPassword);
    
}
