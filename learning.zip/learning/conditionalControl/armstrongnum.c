#include <stdio.h>
#include <string.h> 
#include <math.h>
int main()
{
    int num;
    printf("Enter the num: ");
    scanf("%d",&num);

    char str[20];   // Buffer to hold the number as a string
    sprintf(str, "%d", num);  // Convert number to string

    int length = 0;
    while (str[length] != '\0') {
        length++;  // Count characters
    }

    // printf("Number of digits: %d\n", length);

    int temp = num;

    // This loop extracts digits in reverse order (3, then 2, then 1)
    int sum=0;
    while(temp > 0) {
        int holder=0;
        int digit = temp % 10;
        // Do something with digit
        printf("Digit: %d\n", digit);
        
        holder = (int)pow(digit, length);
        sum += holder;
        temp /= 10;
    }
    printf("Result: %d\n",sum);

    if(num == sum)
    {
        printf("Given number %d is armstrong number.\n",num);

    }
    else
    {
        printf("Given number %d is not armstrong number.\n",num);
    }
    
    return 0;
}