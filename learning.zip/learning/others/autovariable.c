#include <stdio.h>  
  
int main() {  
    auto int count = 10;  
    printf("Count: %d\n", count);  
  
    {  
        auto int count = 5;  
        printf("Inner Count: %d\n", count);  
    }  
  
    printf("Count: %d\n", count);  
  
    return 0;  
}  