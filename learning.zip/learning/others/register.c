#include <stdio.h>  
  
int main() {  

    register int reg_var = 5;  
    printf("Register Variable: %d\n", reg_var);  
  
    return 0;  
}  