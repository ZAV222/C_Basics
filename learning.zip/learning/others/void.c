#include <stdio.h>  
  
void printMessage() {  
    printf("Hello, World!\n");  
}  
  
int main() {  
    printMessage();  
  
    return 0;  
}  