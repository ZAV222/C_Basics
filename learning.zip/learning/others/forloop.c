#include <stdio.h>  
  
int main() {  
    for (int i = 0; i< 5; i++) {  
    printf("%d ", i);  
    }  
    printf("\n");  
  
    return 0;  
}  