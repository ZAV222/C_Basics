
#include<stdio.h>  

int main(){   

    const float PI=3.14;    
    printf("The value of PI is: %f\n",PI);    
    return 0;  
}     