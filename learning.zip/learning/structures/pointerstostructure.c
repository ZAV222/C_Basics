#include <stdio.h>
#include <string.h>

// user defined structure.
struct student
{
    int roll;
    float cgpa;
    char name[100];

};

int main()
{
    // initializating structure

    struct student s1 = {1334,3.2,"Rajesh"};

    printf("Student name: %s\n",s1.name);

    // Accessing using pointers
    struct student *ptr;

    ptr = &s1;
    printf("Student name: %s\n",(*ptr).name);
    
    return 0;
}