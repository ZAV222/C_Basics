#include <stdio.h>  
  
int main() {  
    float weight = 65.5;  
    printf("Weight: %.2f\n", weight);  
  
    return 0;  
}  