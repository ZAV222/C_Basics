#include <stdio.h>

// int sum(int a, int b);

void printTable(int n);


int main()
{
    // int a;
    // int b;
    int n;

    // printf("Enter the value of a: ");
    // scanf("%d",&a);

    // printf("Enter the value of b: ");
    // scanf("%d",&b);

    // int s = sum(a,b);

    // printf("The sum of a and b is: %d\n",s);


    printf("Enter the number: ");
    scanf("%d",&n);
    
    printTable(n);
    return 0;

}

// int sum(int a, int b)
// {
//     return a+b;
// }

void printTable(int n)
{
    int tabler = 1;

    while (tabler<=10)
    {
        int c = n*tabler;
        printf("%d x %d = %d\n",n,tabler,c);
        tabler = tabler+1;
    }
    
}