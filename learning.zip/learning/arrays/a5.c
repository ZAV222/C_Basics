#include <stdio.h>

void printNumbers(int arr[],int n);

int main()
{
    int arr[] = {1,2,3,4,5,6};
    printNumbers(arr,6);
    return 0;
}



void printNumbers( int *arr /*arr[]*/ , int n )
{
    int looper = 0;

    while (looper<n)
    {
        printf("%d \t",arr[looper]);
        looper = looper+1;
    }
    printf("\n");
}