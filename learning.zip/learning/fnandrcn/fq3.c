#include <stdio.h>
#include <math.h>

int square(int n);
float circle(float n);
int rectangle(int x, int y);

int main()
{
    int l = 2;
    int b = 2;
    // int square = pow(num,2);
    // printf("Square: %d\n",square);

    int areaOfSquare = square(l);
    float areaOfCircle = circle((float)l);
    int areaOfRectangle = rectangle(l,b);

    printf("Area of Square: %d\nArea of Circle: %f\nsArea of Rectangle: %d\n",areaOfSquare,areaOfCircle,areaOfRectangle);

    return 0;
}

int square(int n)
{
    return (int)pow(n,2);
}

float circle(float n)
{ 
    float area = 3.14 *n*n;
    
    return area;
     
}

int rectangle(int x, int y)
{
    return x*y;
}