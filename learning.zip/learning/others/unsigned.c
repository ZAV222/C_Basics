#include <stdio.h>  
  
int main() {  
    
    unsigned int count = 100;  
    printf("Count: %u\n", count);  
  
    return 0;  
}  