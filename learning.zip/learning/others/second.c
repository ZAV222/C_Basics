#include<stdio.h>    

int main(){

int number; 

printf("enter a number:");    
scanf("%d",&number);    
printf("cube of number is:%d ",number*number*number);  
printf("\n");  

return 0;  
}    