#include "globals.h"

int x = 10;    // Definition and initialization of x
int y = 20;    // Definition and initialization of y
