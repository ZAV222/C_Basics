#include <stdio.h>


int main()
{
    FILE *fptr;

    fptr = fopen("Test.txt","r");

    char ch;
    ch = fgetc(fptr);
    int vcount = 0;
    while (ch != EOF)
    {
        if (ch == 'A' || ch == 'E' || ch == 'I' || ch=='O' || ch == 'U' || ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' )
        {
            vcount = vcount+1;
            printf("%c : %d\n",ch,vcount);
            
            
        }
        
        
        ch = fgetc(fptr);
    }
    printf("No of vowels: %d",vcount);
    printf("\n");
    
    fclose(fptr);

    return 0;
}