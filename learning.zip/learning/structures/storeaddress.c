#include <stdio.h>
#include <string.h>

// user defined structure using alias std.
typedef struct address
{
    int houseNo;
    int block;
    char city[10];
    char state[10];

}ads;

int main() {
    ads a1[5];
    
    a1[0] = (ads){233, 3, "Itahari", "Koshi"};
    a1[1] = (ads){234, 4, "Dholakpur", "Koshi"};
    a1[2] = (ads){235, 5, "Illam", "Koshi"};
    a1[3] = (ads){236, 6, "Namche", "Koshi"};
    a1[4] = (ads){237, 7, "Kamche", "Koshi"};
    
    printf("Address of first student: \n");
    printf("House no of first student: %d\n",a1[0].houseNo);
    printf("Block no of first student: %d\n",a1[0].block);
    printf("city of first student: %s\n",a1[0].city);
    

    return 0;
}