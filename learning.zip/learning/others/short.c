#include <stdio.h>  
  
int main() {  
    
    short temperature = -10;  
    printf("Temperature: %d\n", temperature);  
  
    return 0;  
}  