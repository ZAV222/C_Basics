#include <stdio.h>  
  
void increment() {
      
    static int count = 0;  
    count++;  
    printf("Count: %d\n", count);  
}  
  
int main() {

    increment();  
    increment();  
  
    return 0;  
}  