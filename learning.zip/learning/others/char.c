#include <stdio.h>  
  
int main() {  
    char grade = 'A';  
printf("Grade: %c\n", grade);  
  
    return 0;  
}  