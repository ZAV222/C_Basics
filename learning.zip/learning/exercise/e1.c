#include <stdio.h>

int main(){
    int num;
    printf("Write the number you want to check: ");
    scanf("%d",&num);

    if (num%2 == 0)
    {
        printf("Your given number is divisible by 2.\n");
    
    }
    else
    {
        printf("Your given number is not divisible by 2.\n");
    }
    
    
    return 0;
}