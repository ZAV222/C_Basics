#include <stdio.h>

int main()
{
    int m1 = 97;
    int m2 = 92;
    int m3 = 90;

    int marks[] = {97,92,90};

    int mrk[3];

    printf("Enter the marks of physice: ");
    scanf("%d",&mrk[0]);

    printf("Enter the marks of math: ");
    scanf("%d",&mrk[1]);

    printf("Enter the marks of english: ");
    scanf("%d",&mrk[2]);

    printf("physics: %d, math: %d, english: %d\n",mrk[0],mrk[1],mrk[2]);
    return 0;
}