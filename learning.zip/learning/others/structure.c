#include <stdio.h>  
#include <string.h>   
// Define a structure representing a person  
struct Person {  
    char name[50];  
    int age;  
    float height;  
};  
   
int main() {  
    // Declare a variable of type struct Person  
    struct Person person1;  
   
    // Assign values to the structure members  
    strcpy(person1.name, "John Doe");  
    person1.age = 30;  
    person1.height = 1.8;  
   
    // Accessing the structure members  
    printf("Name: %s\n", person1.name);  
    printf("Age: %d\n", person1.age);  
    printf("Height: %.2f\n", person1.height);  


    printf("\n\n");
     // Declare a variable of type struct Person  
     struct Person p2;  
   
     // Assign values to the structure members  
     strcpy(p2.name, "parikshit Acharya");  
     p2.age = 21;  
     p2.height = 1.79;  
    
     // Accessing the structure members  
     printf("Name: %s\n", p2.name);  
     printf("Age: %d\n", p2.age);  
     printf("Height: %.2f\n", p2.height);  
   
    return 0;  
}  