#include <stdio.h>
#include <string.h>

// user defined structure.
struct student
{
    int roll;
    float cgpa;
    char name[100];

};

int main()
{
    struct student ece[5];
    ece[0].roll = 1334;
    ece[0].cgpa = 3.12;
    strcpy(ece[0].name,"Ramesh");

    printf("Student name is: %s\n",ece[0].name);
    printf("Student rollno is: %d\n",ece[0].roll);
    printf("Student cgpa is: %.1f\n",ece[0].cgpa);

    printf("\n");
    // initializating structure

    struct student s1 = {1334,3.2,"Rajesh"};

    printf("Student name: %s\n",s1.name);
    
    return 0;
}