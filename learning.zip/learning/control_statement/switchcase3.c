#include <stdio.h>  

int main()  
{  
    int x = 10, y = 5;  

    switch((int)(x>y && x+y>0))
    {  
        case 1:   
        printf("hi\n");  
        break;   

        case 0:   
        printf("bye\n");  
        break;  

        default:   
        printf(" Hello bye \n");  
    }   
          
}  