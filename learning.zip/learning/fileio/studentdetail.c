#include <stdio.h>

int main()
{
    FILE *fptr;
    fptr = fopen("studentdetails.txt", "w");

    char name[10];
    int marks;
    char course[10];
    float cgpa;
    
    

    printf("Enter Name: ");
    scanf("%s",name);

    printf("Enter marks: ");
    scanf("%d",&marks);

    printf("Enter cgpa: ");
    scanf("%f",&cgpa);

    printf("Enter course: ");
    scanf("%s",course);

    fprintf(fptr,"%s | ",name);
    fprintf(fptr,"%d | ",marks);
    fprintf(fptr,"%.f | ",cgpa);
    fprintf(fptr,"%s \n",course);









    // printf("%s\n",name);
    fclose(fptr);

    return 0;
}