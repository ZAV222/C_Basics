#include <stdio.h>  
  
int main() {  

    int age = 20;  

    if (age >= 18) 
    {  
    printf("You are an adult.\n");  
    } 

    else 
    {  
    printf("You are not an adult.\n");  
    }  
  
    return 0;  
}  