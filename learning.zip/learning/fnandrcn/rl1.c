#include <stdio.h>

// void printHW(int count);

// int sum(int n);
int fact(int x);
int main()
{
    // printHW(5);

    // int Totalsum = sum(5);
    // printf("Total Sum: %d\n",Totalsum);

    int resulter = fact(4);
    printf("Factorial: %d\n",resulter);
   
    return 0;
}

// // Recursive function
// void printHW(int count)
// {
//     if (count == 0)
//     {
//         return;
//     }
    
//     printf("Hello World\n");
//     printHW(count-1);
// }

// int sum(int n)
// {
//     if (n==1)
//     {
//         return 1;
//     }
    
//     int sumN1 = sum(n-1); 
//     int sumN = sumN1 + n;

//     return sumN;

// }

int fact(int x)
{
    if (x==1)
    {
        return 1;
    }
    
    int lesser = fact(x-1);
    int result = x*lesser;

    return result;

}