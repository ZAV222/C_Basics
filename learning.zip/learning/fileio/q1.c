#include <stdio.h>

int main()
{
    FILE *fptr;
    fptr = fopen("ii.txt","r");

    int i;
    
    fscanf(fptr,"%d",&i);
    printf("%d\n",i);
    fscanf(fptr,"%d",&i);
    printf("%d\n",i);
    fscanf(fptr,"%d",&i);
    printf("%d\n",i);
    fscanf(fptr,"%d",&i);
    printf("%d\n",i);
    fscanf(fptr,"%d",&i);
    printf("%d\n",i);
   
    


    fclose(fptr);
    return 0;
}