#include <stdio.h>
#include <stdlib.h>

int main()
{
 
    int *ptr;

    ptr = (int*)calloc(5,sizeof(int));

    
    int looper = 0;
    while (looper<5)
    {
        printf("Enter the number of ptr[%d]: ",looper);
        scanf("%d",&ptr[looper]);
        looper = looper+1;
    }
    printf("\n");
    
    free(ptr);
    ptr = (int*)calloc(6,sizeof(int));

    looper = 0;
    while (looper<6)
    {
        printf("Enter the number of ptr[%d]: ",looper);
        scanf("%d",&ptr[looper]);
        looper = looper+1;
    }
    printf("\n");
  
    looper = 0;
    while (looper < 6)
    {
        printf("the number for ptr[%d]: %d\n",looper,ptr[looper]);
        
        looper = looper+1;
    }
    
    free(ptr);


    return 0;
}