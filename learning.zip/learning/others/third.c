#include <stdio.h>

int main(){
    int x;
    int y;
    int result;

    printf("Enter the first number: ");
    scanf("%d",&x);  
    printf("\n");

    printf("Enter the second number: ");
    scanf("%d",&y);  
    printf("\n");


    result = x+y;

    printf("The result is: %d", result);
    printf("\n");
    return 0; 



}