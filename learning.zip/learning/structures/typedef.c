#include <stdio.h>
#include <string.h>

// user defined structure using alias std.
typedef struct student
{
    int roll;
    float cgpa;
    char name[100];

}std;

int main()
{
    // initializating structure

    std s1 = {1334,3.2,"Rajesh"}; // This is how you can use std.

    printf("%s\n",s1.name);

   
    return 0;
}

