#include <stdio.h>
#include <math.h>

int main()
{
    int num = 2;
    int square = pow(num,2);
    printf("Square: %d\n",square);
    return 0;
}