#include <stdio.h>  
  
enum Days {  
    Monday,  
    Tuesday,  
    Wednesday,  
    Thursday,  
    Friday,  
    Saturday,  
    Sunday  
};  
  
int main() {  

    enum Days today = Tuesday;  

    printf("Today is day number %d\n", today);  
  
    return 0;  
}  