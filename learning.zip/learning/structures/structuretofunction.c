#include <stdio.h>
#include <string.h>

// user defined structure.
struct student
{
    int roll;
    float cgpa;
    char name[100];

};

void printInfo(struct student s1);

int main()
{
    // initializating structure

    struct student s1 = {1334,3.2,"Rajesh"};

    printInfo(s1);

   
    return 0;
}

void printInfo(struct student s1)
{
    
    printf("Student name: %s\n",s1.name);
    printf("Student roll: %d\n",s1.roll);
    printf("Student cgpa: %.1f\n",s1.cgpa);
}