#include <stdio.h>

int main()
{
    FILE *fptr;
    fptr = fopen("odd.txt", "w");

    int start = 1;
    int end;

    printf("Enter end: ");
    scanf("%d",&end);

    while (start<=end)
    {
        if (start%2 !=0)
        {
            fprintf(fptr,"%d ",start);
        }
        start = start+1;
    }
    printf("\n");
    fclose(fptr);

    return 0;
}