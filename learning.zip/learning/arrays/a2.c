#include <stdio.h>


int main()
{
    float item[3];
    printf("Enter the price of Dal: ");
    scanf("%f",&item[0]);

    printf("Enter the price of bhat: ");
    scanf("%f",&item[1]);

    printf("Enter the price of tarkari: ");
    scanf("%f",&item[2]);

    float priceWithoutGST = item[0]+item[1]+item[2];
    float GST = 0.18*priceWithoutGST;
    float finalPrice = priceWithoutGST +GST;
    printf("the final price with gst: %.2f\n",finalPrice);
    return 0;
}