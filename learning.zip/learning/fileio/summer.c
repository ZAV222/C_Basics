#include <stdio.h>

int main()
{
    FILE *fptr;
    fptr = fopen("summer.txt", "r");

    int a;
    int b;

    fscanf(fptr, "%d",&a);
    fscanf(fptr, "%d",&b);

    printf("%d",a);
    printf("%d",b);

    fclose(fptr);
    printf("\n");
    
    FILE *nfptr;
    nfptr = fopen("adder.txt", "w");

    
    int sum = a+b;


    fprintf(nfptr,"%d",sum);
   

    fclose(nfptr);


    


    return 0;
}