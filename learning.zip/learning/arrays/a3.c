#include <stdio.h>
int main() 
{
    // int x = 42;
    // int *ptr = &x;
    // float x = 42.0;
    // float *ptr = &x;
    // char x = 'a';
    // char *ptr = &x;
    // printf("Pointer address: %p\n", ptr);
    // ptr = ptr + 1;
    // printf("Pointer address: %p\n", ptr);
    // ptr = ptr + 1;
    // printf("Pointer address: %p\n", ptr);
    // ptr = ptr + 1;
    // printf("Pointer address: %p\n", ptr);

    // int age = 22;
    // int _age = 23;

    // int *ptr = &age;
    // int *_ptr = &_age;
    // int diff = _ptr - ptr;
    // printf("diff = %u\n", diff);

    // _ptr = &age;

    // printf("Comparison = %u\n",ptr == _ptr);
    return 0;
}