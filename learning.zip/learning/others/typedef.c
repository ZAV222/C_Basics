#include <stdio.h>  
  
typedef int marks;  
  
int main() {  

    marks math_marks = 95;  
    
    printf("Math Marks: %d\n", math_marks);  
  
    return 0;  
}  