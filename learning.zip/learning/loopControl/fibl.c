#include <stdio.h>

int main()
{
    #include <stdio.h>


    int n, count = 0;
    printf("Enter the number of Fibonacci terms: ");
    scanf("%d", &n);
    
    int a = 0, b = 1, next;
    printf("Fibonacci series: ");
    
    while (count < n) {
        printf("%d ", a);
        next = a + b;  // Calculate next term
        a = b;         // Update a to the current b
        b = next;      // Update b to the new term
        count++;
    }
    
    return 0;
}

    

