#include <stdio.h>

float perc(float sm, float mm, float skm);

int main()
{
    float sm = 70;
    float mm = 80;
    float skm = 85;

    float actualPercentage = perc(sm,mm,skm);
    printf("Percetage: %f\n",actualPercentage);
    return 0;
}

float perc(float sm, float mm, float skm)
{
    float sumOfMarks = sm+mm+skm;
    float totalMarks = 300;
    float percentage = (sumOfMarks/totalMarks)*100;

    return percentage;
}