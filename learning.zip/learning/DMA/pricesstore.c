#include <stdio.h>
#include <stdlib.h>

int main()
{
 
    int *prices;
    prices = (int*)malloc(5 * sizeof(int));

    prices[0] = 20;
    prices[1] = 30;
    prices[2] = 40;
    prices[3] = 50;
    prices[4] = 60;

    int looper = 0;

    while (looper<5)
    {
        printf("price of %d : %d \n",looper,prices[looper]);
        looper = looper+1;
    }
    return 0;
}