#include <stdio.h>

int main(){
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);
    if (num%2 == 0)
    {
        printf("Number: %d, is an even number", num);
    }
    printf("\n");
    

}