#include <stdio.h>
#include <string.h>
int main()
{
    char str[20];
    char ch;
    int looper = 0;
    while (ch != '\n')
    {
        scanf("%c",&ch);
        str[looper] = ch;
        looper = looper+1;
    }

    str[looper] = '\0';
    puts(str);

  
    
    return 0;
}