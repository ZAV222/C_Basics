#include <stdio.h>  
  
extern int global_variable;  
  
int main() {  
    global_variable = 10;  
    printf("Global variable: %d\n", global_variable);  
  
    return 0;  
}  
  
int global_variable;  