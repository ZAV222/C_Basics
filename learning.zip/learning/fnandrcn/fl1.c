#include <stdio.h>

void printHello();
void justHello();
void justGoodBye();

int main()
{
    printHello();
    printHello();
    justHello();
    justGoodBye();
    return 0;
}

void printHello()
{
    printf("Hello World.\n");
}

void justHello()
{
    printf("Hello!\n");
}

void justGoodBye()
{
    printf("good bye.\n");
}