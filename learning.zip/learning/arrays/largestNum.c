#include <stdio.h>
    
int main() {
    int arr[5] = {1, 8, 3, 4, 5};
    int holder = arr[0]; // Initialize with the first element
    int looper = 1;       // Start from the second element

    while (looper < 5) {
        if (arr[looper] > holder) {
            holder = arr[looper]; // Update holder if current element is larger
        }
        looper++; // Move to next element
    }

    printf("The highest number is: %d\n", holder);
    return 0;
}
    
 