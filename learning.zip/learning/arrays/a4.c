#include <stdio.h>

int main()
{
    int aadhar[5];

    int *ptr = &aadhar[0];

    int start = 0;

    while(start<5)
    {
        printf("%d index: ",start);
        scanf("%d", ptr+start);
        start = start+1;

    }

    printf("\n");



    start = 0; // Reset to 0
    while (start<5)
    {
        printf("%d index = %d\n",start, aadhar[start] /**(ptr+start)*/);
        start = start+1;
    }
    


    return 0;
}