#include <stdio.h>

void reverser(int arr[], int n);
int main()
{
    int arr[4] = {1,2,3,4};

    reverser(arr,4);
    
    int looper = 0;
    while (looper<4)
    {
        printf("%d\n",arr[looper]);
        looper = looper+1;
    }
    
    return 0;
}

void reverser(int arr[], int n)
{
    int looper = 0;

    while (looper<n/2)
    {
        int firstVal = arr[looper];
        int lastVal = arr[n-looper-1];
        arr[looper] = lastVal;
        arr[n-looper-1] = firstVal;
        looper = looper+1;



    }
    
    
}