#include <stdio.h>

int main()
{
    int marks[2][3] = {{97,96,95},{88,89,90}};

    printf("%d\n",marks[0][0]);
    return 0;
}