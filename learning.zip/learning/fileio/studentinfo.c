#include <stdio.h>

int main()
{
    FILE *fptr;
    fptr = fopen("studentinfo.txt", "w");

    char name[10];
    int age;
    char address[10];
    
    
    

    printf("Enter Name: ");
    scanf("%s",name);

    printf("Enter age: ");
    scanf("%d",&age);

    printf("Enter address: ");
    scanf("%s",address);

    fprintf(fptr,"%s ",name);
    fprintf(fptr,"%d ",age);
    fprintf(fptr,"%s ",address);









    // printf("%s\n",name);
    fclose(fptr);

    return 0;
}