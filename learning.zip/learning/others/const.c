#include <stdio.h>  
  
int main() {  
const int MAX_SIZE = 100;  
printf("Max Size: %d\n", MAX_SIZE);  
  
    return 0;  
}  