#include <stdio.h>

void maximum(int *a, int *b);
int main()
{
    int a = 2;
    int b = 5;

    maximum(&a,&b);
    return 0;
}

void maximum(int *a, int *b)
{
    if (*a>*b)
    {
        printf("Max: %d\n",*a);

    }
    else if (*b>*a)
    {
        printf("Max: %d\n",*b);
    }
    else
    {
        printf("Error\n");
    }
    
    
    
}