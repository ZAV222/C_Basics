#include <stdio.h>
#include <ctype.h>  // Required for isupper() and islower()
#include <string.h>
int main() {
    char str[] = "Hello";


    // int index = 2;  // Check the third character

    // Cast to unsigned char to avoid undefined behavior
    // if (isupper((unsigned char)str[index])) {
    //     printf("Character '%c' is uppercase.\n", str[index]);
    // } else if (islower((unsigned char)str[index])) {
    //     printf("Character '%c' is lowercase.\n", str[index]);
    // } else {
    //     printf("Character '%c' is not a letter.\n", str[index]);
    // }

    int looper = 0;
    while (str[looper] != '\0')
    {
     
        if (isupper((unsigned char)str[looper])) 
        {
            str[looper] = tolower(str[looper]);
        } 
        else if (islower((unsigned char)str[looper])) 
        {
            str[looper] = toupper(str[looper]);
        }

        looper = looper+1;
    }
    
    puts(str);

    return 0;
}