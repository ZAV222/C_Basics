#include <stdio.h>

void calculateOdd(int arr[],int n);
int main()
{
    int arr[5] = {1,2,3,4,5};
    calculateOdd(arr,5);
    
    // printf("%d and %d",*(arr+2),*(arr+6));

    return 0;
}

void calculateOdd(int arr[], int n)
{
    int looper = 0;

    while (looper<n)
    {
        if (arr[looper]%2 != 0)
        {
            printf("%d ",arr[looper]);
        }

        looper = looper+1;
        
    }
    printf("\n");
    
}

