#include <stdio.h>

int main() {
    // Declare an array with extra capacity.
    int arr[10] = {1, 8, 3, 4, 5};
    int capacity = sizeof(arr) / sizeof(arr[0]);  // Total capacity is 10
    int length = 5;  // Logical length: number of valid elements initially

    // Print the initial array using a while loop
    int looper = 0;
    printf("Initial array: ");
    while (looper < length) {
        printf("%d ", arr[looper]);
        looper = looper+1;
    }
    printf("\n");

    // Insert a new element at the end using a while loop approach
    int newElement;
    printf("Enter an element to insert at the end: ");
    scanf("%d", &newElement);

    // Check if there's room in the array before inserting
    if (length < capacity) {
        // We want to insert at the position 'length'
        arr[length] = newElement;
        length = length+1; // Update the logical length
    } else {
        printf("Array is full. Cannot insert element.\n");
    }

    // Print the array after insertion using a while loop
    looper = 0;  // Reset loop counter
    printf("Array after insertion: ");
    while (looper < length) {
        printf("%d ", arr[looper]);
        looper = looper+1;
    }
    printf("\n");

    return 0;
}
