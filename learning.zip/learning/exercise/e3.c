#include <stdio.h>

int main(){
    char x;
    
    printf("Enter a character: ");
    scanf("%c",&x);
    
    if (x>='a' && x<='z')
    {
        printf("Lower Case\n");
    }
    else if (x>='A' && x<='Z')
    {
        printf("Upper Case\n");
    }
    else
    {
        printf("Invalid");
    }

    return 0;
}
