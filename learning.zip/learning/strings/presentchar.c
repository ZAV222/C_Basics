#include <stdio.h>
#include <ctype.h>
#include <string.h>

void checker(char str[],char check);
int main()
{

    char str[] = "Apple";

    char check;
    printf("Enter the character you want check: ");
    scanf("%c",&check);

    checker(str,check);
    
    return 0;
}

void checker(char str[],char check)
{
    int looper = 0;
    int present = 0;
    
    while (looper<6)
    {
        str[looper] = tolower(str[looper]);
        if (str[looper] == check)
        {
            present = present+1;
            

        }
        looper = looper+1;
    }
    printf("%d time your character is present.\n",present);
}