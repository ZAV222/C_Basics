#include <stdio.h>

int main()
{
    FILE *fptr;
    // // Readding data
    // fptr = fopen("Test.txt","r");

    
    // int ch;

    // fscanf(fptr,"%d",&ch);
    // printf("Character = %d\n", ch);
    // fscanf(fptr,"%d",&ch);
    // printf("Character = %d\n", ch);
    // fscanf(fptr,"%d",&ch);
    // printf("Character = %d\n", ch);
    // // fscanf(fptr,"%d",&ch);
    // // printf("Character = %d\n", ch);
    // // fscanf(fptr,"%d",&ch);
    // // printf("Character = %d\n", ch);
    // fclose(fptr);

    // Writing Data
    fptr = fopen("Test.txt","r");
    
    char ch;
    ch = fgetc(fptr);
    while (ch !=EOF)
    {
        printf("%c",ch);
        ch = fgetc(fptr);
    }
    printf("\n");
    

    // fputc('M',fptr);
    // fputc('A',fptr);
    // fputc('N',fptr);
    // fputc('G',fptr);
    // fputc('O',fptr);

    // printf("%c ",fgetc(fptr));
    // printf("%c ",fgetc(fptr));
    // printf("%c ",fgetc(fptr));
    // printf("%c ",fgetc(fptr));
    // printf("%c\n",fgetc(fptr));
    // fprintf(fptr,"%s","M");
    // fprintf(fptr,"%s","a");
    // fprintf(fptr,"%s","n");
    // fprintf(fptr,"%s","g");
    // fprintf(fptr,"%s","o");



    fclose(fptr);
    return 0;
}