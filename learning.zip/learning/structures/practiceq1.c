// Write a program to store 3 information of 3 student.

#include <stdio.h>
#include <string.h>
// user defined structure.
struct student
{
    int roll;
    float cgpa;
    char name[100];

};


int main()
{

    struct student s1;

    s1.roll = 10;
    s1.cgpa = 3.2;
    strcpy(s1.name,"Parikshit");

    printf("Student name is: %s\n",s1.name);
    printf("Student rollno is: %d\n",s1.roll);
    printf("Student cgpa is: %.1f\n",s1.cgpa);
    
    printf("\n");
    struct student s2;

    s2.roll = 9;
    s2.cgpa = 3.1;
    strcpy(s2.name,"Ankit");

    printf("Student name is: %s\n",s2.name);
    printf("Student rollno is: %d\n",s2.roll);
    printf("Student cgpa is: %.1f\n",s2.cgpa);

    printf("\n");
    struct student s3;

    s3.roll = 8;
    s3.cgpa = 3.4;
    strcpy(s3.name,"shyam");

    printf("Student name is: %s\n",s3.name);
    printf("Student rollno is: %d\n",s3.roll);
    printf("Student cgpa is: %.1f\n",s3.cgpa);
    
    return 0;
}