#include <stdio.h>  
  
int main() {  
    
    int number = 10;  
    printf("Number: %d\n", number);  
  
    return 0;  
}  