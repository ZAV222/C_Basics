#include <stdio.h>

int main() {
    // int num;
    
    // printf("Enter a number: ");
    // scanf("%d", &num);
    
    // if (num <= 1) {
    //     printf("%d is not a prime number.\n", num);
        
    // }
    // else if (num == 2 || num == 3 || num == 5 || num ==7)
    // {
    //     printf("%d is a prime number\n", num);
    // }
    // else if (num%2 == 0 || num%3 == 0 || num%5 == 0 || num%7 == 0)
    // {
    //     printf("%d is not a prime number.\n",num);
    // }
    // else if (num%2 != 0 || num%3 != 0 || num%5 != 0 || num%7!= 0 )
    // {
    //     printf("%d is a prime number\n", num);
    // }
    // else
    // {
    //     printf("Error");
    // }

    
    int num1;
    int num2;
    printf("Enter a number 1st: ");
    scanf("%d", &num1);

    printf("Enter a number 2nd: ");
    scanf("%d", &num2);
    
    while (num1<=num2)
    {
        if (num1 <= 1) {
            printf("%d is not a prime number.\n", num1);
            
        }
        else if (num1 == 2 || num1 == 3 || num1 == 5 || num1 ==7)
        {
            printf("%d is a prime number\n", num1);
        }
        else if (num1%2 == 0 || num1%3 == 0 || num1%5 == 0 || num1%7 == 0)
        {
            printf("%d is not a prime number.\n",num1);
        }
        else if (num1%2 != 0 || num1%3 != 0 || num1%5 != 0 || num1%7!= 0 )
        {
            printf("%d is a prime number\n", num1);
        }
        else
        {
            printf("Error");
            break;
        }

        num1 = num1 + 1;
    }
    


    

    
    return 0;
}
