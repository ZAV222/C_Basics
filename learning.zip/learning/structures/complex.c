#include <stdio.h>

typedef struct complex
{
    int real;
    int img;
}cp;

int main()
{
    cp complex1 = {2,3};
    cp *ptr;
    ptr = &complex1;

    // printf("img part: %d\n",(*ptr).img);

    printf("Real part: %d\n",(*ptr).real);
    printf("Img part: %d\n",ptr->img);
    return 0;
}