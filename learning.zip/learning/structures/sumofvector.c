#include <stdio.h>
#include <string.h>


typedef  struct sumofvector
{
    int x;
    int y;
}sv;

void calcSum(sv v1, sv v2, sv sum);

int main()
{
    sv v1 = {2,3};
    sv v2 = {3,4};
    sv sum = {0};

    calcSum(v1,v2,sum);
     
    return 0;
}

void calcSum(sv v1, sv v2, sv sum)
{
    sum.x = v1.x + v2.x;
    sum.y = v1.y + v2.y;

    printf("Sum of x: %d\n",sum.x);
    printf("Sum of y: %d\n",sum.y);
}
