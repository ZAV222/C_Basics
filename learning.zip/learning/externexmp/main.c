#include "globals.h"
#include <stdio.h>

int main(void) {
    printf("x = %d, y = %d\n", x, y);
    return 0;
}
