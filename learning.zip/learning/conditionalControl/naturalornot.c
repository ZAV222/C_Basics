#include <stdio.h>

int main(void) {
    int num;
    printf("Enter a number: ");
    
    // scanf returns 1 if an integer is successfully read
    if (scanf("%d", &num) != 1) {
        printf("Invalid input\n");
        return 1; // Exit with an error code
    }
    else if (num>0)
    {
        printf("Your number is natural number.\n");
    }
    
    return 0;
}