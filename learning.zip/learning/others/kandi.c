// keyword and identifiers example

#include <stdio.h>

int main()  
{  
    int a=10;  
    int A=20;  

    printf("Value of a is : %d",a);  
    printf("\nValue of A is : %d",A);  
    printf("\n");
    return 0;  
}  