#include <stdio.h>

int main()
{
    // int x=1;
    // while (x <= 10)
    // {
    //     printf("%d\n", x);
    //     x=x+1;
    // }

    // int x = 0;
    // int num = 0;
    // printf("Enter the num: ");
    // scanf("%d",&num);

    // while (x <= num)
    // {
    //     printf("%d\n",x);
    //     x = x+1;
    // }
    

    // int num = 1;
    // do
    // {
    //     printf("%d\n",num);
    //     num = num+1;

    // } while (num<=5);


    // Sum of naturan number which is given by users and reversing it.

    // int num = 1;
    // int x;
    // printf("Enter the num: ");
    // scanf("%d",&x);

    // int sum = 0;
    // while (num<=x)
    // {
    //     // printf("%d\n",num);
    //     sum = sum+num;
    //     num = num+1;
    // }
    // printf("sum is: %d\n",sum);

    // int rev = num-1;
    // while (rev!=0)
    // {
    //     printf("%d\n",rev);

    //     rev = rev-1;
    // }
    
    
    //Printing table of any given number.

    // int num=0;
    // printf("Enter the num: ");
    // scanf("%d",&num);
    // int tabler = 1;
    // int temp;
    // while(tabler<=10)
    // {
    //     temp = num * tabler;
    //     printf("%d x %d = %d\n",num,tabler,temp);
    //     tabler = tabler + 1;
    // }

    // ask until user input odd number.
    // int num=0;
    // // printf("Enter the num: ");
    // // scanf("%d",&num);

    // while (num%2 == 0)
    // {
    //     printf("Enter the num: ");
    //     scanf("%d",&num);
    //     printf("%d\n",num);
    // }
    
    // // Ask until user inputs multiple of 7.
    // int num;
    // printf("Enter the num: ");
    // scanf("%d",&num);

    // while (num%7 != 0)
    // {
    //     printf("Enter the num: ");
    //     scanf("%d",&num);
    //     printf("%d\n",num);
    // }

    // int num = 1;
    // while (num<=10)
    // {
    //     if (num==6)
    //     {
    //         num = num+1;
    //         continue;
    //     }
        
    //     printf("%d\n",num);
    //     num = num + 1;
    // }

    // int n = 5;
    // while (n<=50)
    // {
    //     if (n%2 != 0)
    //     {
    //         printf("%d \n",n);
    //     }
    //     n = n+1;
    // }

    // // Factorial Program
    // int start = 1;
    // int stop = 1;
    // printf("Enter num: ");
    // scanf("%d",&stop);

    // int fact = 1;
    // while (start<=stop)
    // {
        
    //     fact = fact * start;
        
    //     start = start+1;
    // }
    // printf("Factorial is: %d\n",fact);
    

    // // Reverse Table Program

    // int num;
    // printf("Enter the num: ");
    // scanf("%d",&num);

    // int tabler = 10;
    // int res;
    // while (tabler>0)
    // {
    //     res = num * tabler;
    //     printf("%d * %d = %d\n",num,tabler,res);
    //     tabler = tabler-1;
    // }
    

    // Calculate the sum of all number from 5 to 50.

    int x = 5;
    int sum = 0;
    while (x<=50)
    {
        
        sum = sum+x;
        x = x+1;
    }
    
    printf("%d\n",sum);
    return 0;
}