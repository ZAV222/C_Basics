#include <stdio.h>

int main()
{
    int x = 1;
    while (x<=20)
    {
        if (x == 5 || x==10 || x==15)
        {
            printf("*\n");
            x = x+1;
        }
        
        printf("* ");
        x = x+1; 
    }
    printf("\n");
    
    return 0;
}
