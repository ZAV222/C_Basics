#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
    char str[] = "Hello World";
    int frequency[256] = {0}; // Tracks counts for all ASCII characters

    // Convert string to lowercase with while loop
    int looper = 0;
    while (str[looper] != '\0') {
        str[looper] = tolower(str[looper]);
        looper++;
    }

    // Reset looper for counting frequencies
    looper = 0;
    while (str[looper] != '\0') {
        frequency[(unsigned char)str[looper]]++; // Cast to avoid negative indices
        looper++;
    }

    // Print frequencies with while loop
    int i = 0;
    while (i < 256) {
        if (frequency[i] > 0) {
            printf("'%c' appears %d times.\n", (char)i, frequency[i]);
        }
        i++;
    }

    return 0;
}