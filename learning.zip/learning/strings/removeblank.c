#include <stdio.h>
#include <string.h>

int main() {
    char name[] = "Parikshit Acharya";
    char nameWithoutSpace[18]; // Size should match the original string's length
    int i = 0; // Index for original string
    int j = 0; // Index for new string

    while (name[i] != '\0') {
        if (name[i] != ' ') { // Only copy non-space characters
            nameWithoutSpace[j] = name[i];
            j++; // Advance new string's index
        }
        i++; // Always advance original string's index
    }
    nameWithoutSpace[j] = '\0'; // Terminate the new string

    puts(nameWithoutSpace); // Output: ParikshitAcharya
    return 0;
}