#include <stdio.h>
#include <string.h>
// user defined structure.
struct student
{
    int roll;
    float cgpa;
    char name[100];

};


int main()
{

    struct student s1;

    s1.roll = 10;
    s1.cgpa = 3.2;
    strcpy(s1.name,"Parikshit");

    printf("Student name is: %s\n",s1.name);
    printf("Student rollno is: %d\n",s1.roll);
    printf("Student cgpa is: %.1f\n",s1.cgpa);
    
    
    return 0;
}