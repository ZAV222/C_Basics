#include <stdio.h>

void printString(char arr[]);
int main()
{
    char firstName[] = "Parikshit";
    char lastName[] = "Acharya";
    char address[11]; 

    // printString(firstName);
    // printString(lastName);
    // printf("\n");

    printf("%s %s\n",firstName,lastName);

    scanf("%s",address);
    printf("%s\n",address);

    return 0;
}

void printString(char arr[])
{
    int looper = 0;
    while (arr[looper] != '\0')
    {
        printf("%c",arr[looper]);
        looper = looper+1;
    }
    printf(" ");
}