#include <stdio.h>  
  
int main() { 
     
    long population = 1000000;  
    printf("Population: %ld\n", population);  
  
    return 0;  
}  