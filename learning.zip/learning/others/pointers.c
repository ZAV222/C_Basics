#include <stdio.h>  
   
int main() {  
    int num = 42;      // An integer variable  
    int *ptr;          // Declares a pointer to an integer  
   
    ptr = &num; // Assigns the address of '&num' to the pointer  
   
    // Accessing the value of 'num' using the pointer  
    printf("Value of num: %d\n", *ptr);  
   
    return 0;  
}  