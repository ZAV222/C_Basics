#include <stdio.h>

void Namaste();
void Bonjour();

int main()
{
    int x;
    printf("Enter 1 if you are from nepal or 2 if you are french: ");
    scanf("%d",&x);

    if (x==1)
    {
        Namaste();
    }
    else if (x==2)
    {
        Bonjour();
    }
    else
    {
        printf("Error.\n");
    }
    
    
    return 0;
}

void Namaste()
{
    printf("Namaste\n");
}

void Bonjour()
{
    printf("Bonjour");
}