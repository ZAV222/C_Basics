#include <stdio.h>  
#include <string.h>  
  
struct Person {  
    char name[20];  
    int age;  
};  
  
int main() {
      
    struct Person student;  
    strcpy(student.name, "John");  
    student.age = 20;  
    printf("Name: %s, Age: %d\n", student.name, student.age);  
  
    return 0;  
}  