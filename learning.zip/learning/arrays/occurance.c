#include <stdio.h>

int main()
{

    int x = 4;

    int arr[5] = {1,2,4,4,5};

    int looper = 0;

    while (looper<5)
    {
        while(x == arr[looper])
        {
            printf("%d in array at index %d \n", arr[looper],looper);
            looper = looper+1;
        }
        
        looper = looper+1;
    }
   
    

    return 0;

}