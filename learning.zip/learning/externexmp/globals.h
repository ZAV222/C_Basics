#ifndef GLOBALS_H
#define GLOBALS_H

extern int x;   // Declaration of global variable x
extern int y;   // Declaration of global variable y

#endif
