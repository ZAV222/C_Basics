#include <stdio.h>
#include <stdlib.h>

int main()
{
 
    int *ptr;
    ptr = (int*)calloc(5,sizeof(int));
    
    printf("Enter the value of ptr[1]: ");
    scanf("%d",&ptr[0]);

    printf("Enter the value of ptr[2]: ");
    scanf("%d",&ptr[1]);

    printf("Enter the value of ptr[3]: ");
    scanf("%d",&ptr[2]);

    printf("Enter the value of ptr[4]: ");
    scanf("%d",&ptr[3]);

    printf("Enter the value of ptr[5]: ");
    scanf("%d",&ptr[4]);

    printf("\n");
    int looper = 0;

    while (looper<5)
    {
        printf("%d ",ptr[looper]);
        looper = looper+1;
    }
    printf("\n");
    return 0;
}