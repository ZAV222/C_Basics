#include <stdio.h>

typedef struct Bank
{
    char name[10];
    int accno;
}bnk;

int main()
{
    bnk b1 = {"rajesh",3321};
    bnk *ptr;
    ptr = &b1;

    // printf("img part: %d\n",(*ptr).img);

    printf("Name: %s\n",ptr->name);
    printf("acc no: %d\n",ptr->accno);
    return 0;
}